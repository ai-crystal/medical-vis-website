Crystal transfer function exercises
English | 中文请阅读《使用说明.txt》

1. Prepare a writable folder

Extract the entire ZIP into a folder you own, such as Documents/Crystal exercises. Keep the ten XML files together. Create an assets folder beside them. Each XML references files beneath assets/ using relative paths, so you can move the complete exercise folder later. Copy just the resources needed for the exercises you want to try. The ZIP contains only the settings and these instructions.

Find the Resources folder beside Crystal.exe. Use the files from your own authorized installation.

01  CLTF, Manix CT
    From Resources/SceneGeometry-Demo/VolumeData, copy Manix_small_intensity.inforaw into assets.
02  DPTF, registered BraTS-MEN intensity and mask
    From the same VolumeData folder, copy BraTS-MEN_intensity.inforaw and BraTS-MEN_mask.inforaw into assets.
03  Wax cylinder
    Copy SceneGeometry-Demo/VolumeData/SVPT/Candle/wax-cylinder.inforaw from Resources to assets.
04  Insect in amber
    Copy both files from Resources/SceneGeometry-Demo/VolumeData/SVPT/Amber into assets: amber-nodule.inforaw (irregular resin body and cracks) and amber-bugnist-blowfly.inforaw (registered BugNIST blowfly concentration).
05  Jade bunny
    Copy SceneGeometry-Demo/VolumeData/SVPT/Jade/jade-bunny.inforaw from Resources to assets.

The three SVPT exercises also need Resources/SceneGeometry-Demo/EnvironmentLight/studio.hdr. Copy this once into assets. Keep the filenames as shown. The small blowfly grid ships with this version of the demo. For source attribution, see Resources/SceneGeometry-Demo/VolumeData/SVPT/Amber/ATTRIBUTION.txt and the BugNIST project (https://abdahl.github.io/bugnist/). If the VolumeData folder contains RAW and INFO files for Manix or BraTS-MEN, follow the next section for the missing assets.

2. Convert a legacy volume from your installation

Open PowerShell in the extracted exercise folder (the one containing 01-cltf-before.xml). The following uses Python 3.10 or newer and the converter included in Crystal/Scripts. The commands read the original RAW files and create INFORAW files in the exercise copy. They preserve voxel order and scalar values. Run these four lines and enter the full directory containing Crystal.exe at the prompt.

$crystalDir = (Resolve-Path -LiteralPath (Read-Host 'Directory containing Crystal.exe')).Path
$volumeDir = Join-Path $crystalDir 'Resources/SceneGeometry-Demo/VolumeData'
$convert = Join-Path $crystalDir 'Scripts/convert_volume_to_inforaw.py'
$assets = (New-Item -ItemType Directory -Force -Path './assets').FullName

Run only the line for each missing file. The conversion tool checks the input length and output checksum. If a destination already exists, use that copy or create another empty exercise directory for a fresh conversion.

python "$convert" "$volumeDir/Manix_small_intensity.raw" --output "$assets/Manix_small_intensity.inforaw" --resolution 230 230 207 --dataformat short --spacing 2.1701 2.1701 3.1111 --spacing-unit voxel
python "$convert" "$volumeDir/BraTS-MEN_intensity.raw" --output "$assets/BraTS-MEN_intensity.inforaw" --resolution 214 214 138 --dataformat float --spacing 1.1236 1.1236 1.1236 --spacing-unit voxel
python "$convert" "$volumeDir/BraTS-MEN_mask.raw" --output "$assets/BraTS-MEN_mask.inforaw" --resolution 214 214 138 --dataformat ushort --spacing 1.1236 1.1236 1.1236 --spacing-unit voxel

The dimensions above are the original x, y, z sizes before axis permutation. The BraTS intensity and mask must come from the same BraTS-MEN.info acquisition. They share a 214 x 214 x 138 grid. The XML keeps the mask at UShort with nearest-neighbor sampling, StorageRange and no label reassignment. The raw IDs are 0 (background), 500 (9,476 voxels), 600 (72,796 voxels) and 700 (13,057 voxels). Preserving these integers makes the exact label table work.

3. Open the starting scene and change one setting

From the Crystal launcher choose File > Run Scene XML and open a file ending in -before.xml. Leave the camera and exposure fixed. When your edited image has accumulated 2048 samples per pixel (SPP), save your own scene XML and compare it with the -after.xml of the same number. All ten scenes explicitly set the SPP limit to 2048.

01-cltf, 640 x 640. Data Mapper > Transfer functions > Intensity. Select the node at normalized intensity 0.40 and change its opacity from 0.11 to 0. The warm overlying tissue recedes.
02-dptf, 640 x 640. Keep Multiply enabled channels. Under Mask1 > DPTF (labels), select ID 600 and change its opacity from 0 to 0.90. The orange region joins the teal and red regions.
03-wax, 512 x 512. Data Mapper > Advanced materials > Material library > 0 > Optical parameters > Scattering. Change RGB from (0.01, 0.01, 0.01) to (0.59, 0.60, 0.61). Click Validate and apply. Compare the narrow bright band at the base with the broad cream-colored lighting.
04-amber, 512 x 512. At the root of Advanced materials, change Mask1 absorption (RGB) from (0, 0, 0) to (1.15, 1.80, 2.90). Validate and apply. The BugNIST blowfly appears inside the irregular nodule. Its cracks already exist in the intensity field.
05-jade, 512 x 512. Under the first material's Optical parameters, change Absorption from (0.044, 0.044, 0.044) to (0.070, 0.027, 0.044). Validate and apply. Examine the body midtones and ear highlights.

If a file cannot be found, check the extracted folder's assets/ subfolder and the exact filenames. On versions that include the compact Decorated Christmas tree demo, it can also be opened independently from Examples > Run RC Examples. That demo ships with Crystal.
